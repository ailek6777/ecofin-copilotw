# EcoFin Copilot — MVP

A small resource-consumption demo (electricity/water) with AI recommendations,
language switching (RU / KZ / EN), and currency switching (KZT / USD / EUR / RUB).

## Secrets

This project talks to the Anthropic API for the chat feature. The API key is
**never** included in the frontend code or repo. Instead:

- `netlify/functions/chat.js` is a serverless function that reads
  `ANTHROPIC_API_KEY` from the server environment and forwards the request.
- The React component calls `/.netlify/functions/chat`, not
  `api.anthropic.com`, so the key is never exposed to the browser.

### Setup

1. Copy `.env.example` to `.env` and fill in your own key for local dev, or
2. In Netlify: **Site settings → Environment variables → Add variable**
   `ANTHROPIC_API_KEY = <your key>`.

`.env` is already listed in `.gitignore` and will not be committed.

## Local development

```bash
npm install
netlify dev
```

## Deploy

Push to GitHub and connect the repo in Netlify, or run:

```bash
netlify deploy --prod
```

Make sure `ANTHROPIC_API_KEY` is set in the Netlify dashboard before deploying,
or the chat feature will return a config error instead of a response.
